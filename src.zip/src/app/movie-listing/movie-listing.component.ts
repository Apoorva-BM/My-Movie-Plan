import { Component , OnInit} from '@angular/core';

@Component({
  selector: 'app-movie-listing',
  templateUrl: './movie-listing.component.html',
  styleUrls: ['./movie-listing.component.css']
})
export class MovieListingComponent implements OnInit{
	 movies: any[]= [];;
	 
	constructor() {
		this.movies = [];
	 }

  ngOnInit(): void {
    // Add initialization logic here
     this.movies = [
      { title: 'Movie 1', genre: 'Action', language: 'English', description: 'A thrilling action movie' , imageUrl: 'https://tse1.mm.bing.net/th?id=OIP.JMiRnO1O0DJh6CAib1KY2gHaHa&pid=Api&P=0&h=180'},
      { title: 'Movie 2', genre: 'Comedy', language: 'English', description: 'A hilarious comedy movie' ,imageUrl: 'https://tse1.mm.bing.net/th?id=OIP.AJ7PAy0qlCLHpJLD9FhpwwHaHL&pid=Api&P=0&h=180' },
      { title: 'Movie 3', genre: 'Romance', language: 'Hindi', description: 'A Roamntic twisted movie', imageUrl: 'https://tse1.explicit.bing.net/th?id=OIP.RJDFIrifyo8EF4okwjcK0AHaEy&pid=Api&P=0&h=180' },
      { title: 'Movie 4', genre: 'Thriller', language: 'Kannada', description: 'A movie to keep on the edge of your seat ',imageUrl: 'https://tse1.mm.bing.net/th?id=OIP.Z0FJNDJPFaFBxU-shCLZwgHaHf&pid=Api&P=0&h=180' },
      { title: 'Movie 5', genre: 'Horror', language: 'English', description: 'A chilling story' ,imageUrl: 'https://img.buzzfeed.com/buzzfeed-static/static/2018-10/29/12/enhanced/buzzfeed-prod-web-04/enhanced-4849-1540831556-4.jpg'}
      
    ];
  }
}
