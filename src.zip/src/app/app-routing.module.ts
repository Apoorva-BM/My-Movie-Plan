import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MovieListingComponent } from './movie-listing/movie-listing.component';
import { BookingPageComponent } from './booking-page/booking-page.component';
import { UserAuthComponent } from './user-auth/user-auth.component';
import { PaymentComponent } from './payment/payment.component';


const routes: Routes = [
	{path:'', redirectTo:'login',pathMatch:"full"},
	{ path: 'movies', component:MovieListingComponent },
  { path: 'booking', component: BookingPageComponent },
  { path: 'login', component: UserAuthComponent },
  { path: 'payment', component: PaymentComponent }
];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
