import { Component,  OnInit } from '@angular/core';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit{
displayPayment: boolean = false;
  displaySuccess: boolean = false;
  
  ngOnInit(): void {
    // Add initialization logic here
  }
  
  bookTicket(movieId: number): void {
   
    this.displayPayment = true;
  }

 handleSuccess(): void {
    this.displaySuccess = true; 
    console.log("success!");
  }
}
