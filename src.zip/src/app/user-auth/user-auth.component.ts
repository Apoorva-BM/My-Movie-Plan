import { Component , OnInit} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-auth',
  templateUrl: './user-auth.component.html',
  styleUrls: ['./user-auth.component.css']
})
export class UserAuthComponent  implements OnInit{
  username: string = '';
  password: string = '';

constructor(private router: Router) { }

  ngOnInit(): void {
    // Add initialization logic here
  }
  
   loginUser(): void {
    // Logic for handling user login
    console.log('Logging in user: ', this.username);
    this.router.navigate(['/movies']);
  }
}
